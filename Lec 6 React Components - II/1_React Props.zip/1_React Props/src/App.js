import List from "./components/List";
import "./styles.css";
import React from "react";

function App() {
  return (
    <div className="App">
      <h1>Reach me</h1>
      <List />
    </div>
  );
}

export default App;
