### Delete the expense from firestore when the delete button is clicked.

When the delete button is clicked on an expense use the appropriate firebase method to delete the expense from the database.

Note: This is a follow-up question to the previous expense tracker project. So use the same firebase configuration in the solution code.
