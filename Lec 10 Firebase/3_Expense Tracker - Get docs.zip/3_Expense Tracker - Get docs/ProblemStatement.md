### Retrive all the expenses form Cloud Firestore and set it to the state on mount of the React application.

When the app mounts, retrieve all documents of expenses from the collection, and store them in the state using the suitable hook for fetching data.

Note: This is a follow-up question to the previous expense tracker project. So use the same firebase configuration in the solution code.
