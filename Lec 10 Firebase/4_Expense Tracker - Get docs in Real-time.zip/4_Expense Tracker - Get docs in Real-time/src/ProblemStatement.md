### Retrive all the expenses form Cloud Firestore in realtime and set it to the state on mount of the React application.

When the app mounts, retrieve all documents of expenses from the collection in realtime using the appropriate firebase method.

Note: This is a follow-up question to the previous expense tracker project. So use the same firebase configuration in the solution code.
