### Add navigation links to the React app using the Link element of React Router.

Change the Navbar component to add links to the Home, List and Contact pages.

Note: The links to the pages should have the same text as their name.

Expected Output:
<img src="https://files.codingninjas.in/link-app-26138.gif"/>
