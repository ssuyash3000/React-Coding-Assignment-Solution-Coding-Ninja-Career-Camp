### Add dynamic route to the React app to display the item details page.

Change the list route to display the list page on the index route and the items details page on the <b>/list/itemId</b> route.

Add a link element to navigate user to the item details page around the name of each item.

Output:
<img src="https://files.codingninjas.in/dynamic-pages-26219.gif">
