export const items = [
  {
    id: 1,
    name: "iPhone 14 Pro Max",
    image: "https://m.media-amazon.com/images/I/610pghkO81L._SX679_.jpg"
  },
  {
    id: 2,
    name: "Canon 200D",
    image: "https://m.media-amazon.com/images/I/914hFeTU2-L._SX450_.jpg"
  },
  {
    id: 3,
    name: "Macbook Air",
    image: "https://m.media-amazon.com/images/I/71eXNIDUGjL._SX679_.jpg"
  },
  {
    id: 4,
    name: "Samsung S23",
    image: "https://m.media-amazon.com/images/I/61RZDb2mQxL._SX679_.jpg"
  }
];
