### Refactor the code to implement nested routes and display a shared Navbar component.

Change the code to make the top-level pages as nested routes of the Navbar component and remove the redundant imports of the component in each file.
