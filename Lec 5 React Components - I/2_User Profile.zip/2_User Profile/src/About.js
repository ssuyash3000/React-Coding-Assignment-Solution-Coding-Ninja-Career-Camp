export default function About() {
  return (
    <div id="about">
      <p>
        Hi, my name is Pranav. I am a full stack web developer and I have
        developed serveral projects with MERN stack. I am also familiar with
        Python and Django.
      </p>
    </div>
  );
}
