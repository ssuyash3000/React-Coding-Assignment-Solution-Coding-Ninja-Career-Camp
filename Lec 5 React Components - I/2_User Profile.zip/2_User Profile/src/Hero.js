function Hero() {
  return (
    <div id="basicInfo">
      <h3>Name: Pranav Sharad Yeole</h3>
      <p>Email: pranav@google.com</p>
      <p>Phone: 854645544</p>
      <p>Address: ABC, xyz street.</p>
    </div>
  );
}

export default Hero;
