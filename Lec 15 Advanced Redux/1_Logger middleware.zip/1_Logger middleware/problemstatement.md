Logger middleware

Add a middleware function to log the state changes inside the React app.
Create and export a middleware function that logs changes to the console when the state is updated.
Add this middleware inside the Redux store.
