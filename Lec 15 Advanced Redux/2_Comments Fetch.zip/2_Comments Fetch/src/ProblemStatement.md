### Create a React application to retrieve random comments from the web.

Define a state slice that manages loading, error, and success states when fetching comments.

Export the reducer function, action creators, and selector functions from this state slice.

Add the reducer to the store and dispatch the appropriate actions to obtain the desired output.

Expected Output:
<img src="https://files.codingninjas.in/commentsfetch-26833.gif"/>
