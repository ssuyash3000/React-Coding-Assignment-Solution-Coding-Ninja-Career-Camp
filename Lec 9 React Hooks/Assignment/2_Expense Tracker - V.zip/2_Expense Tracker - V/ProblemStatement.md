Expense Tracker - V

Now that you have improved the code structure and reduced the complexity, the team has asked you to implement a feature to edit an expense within the list.
Clicking the edit icon should automatically populate the form with the expense's text and amount. The form's title and submit button should have the text "Edit transaction."
Expected Output:
<img src="https://res.cloudinary.com/dzi9rcqsa/image/upload/v1676711290/ImageAdder_d8rkqq.gif" />
