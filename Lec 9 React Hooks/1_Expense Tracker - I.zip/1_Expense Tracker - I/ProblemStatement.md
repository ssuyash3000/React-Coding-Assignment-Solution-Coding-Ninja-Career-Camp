Expense Tracker - I
Send Feedback
You along with your friends have participated in a hackathon. The entire team has agreed upon building an expense tracker application. The designs for the application are completed.
You have been tasked with implementing the entire functionality. As a first step, you want to change the class based components to functional components and render them in the App.
Expected Output:

<img src="https://res.cloudinary.com/dzi9rcqsa/image/upload/v1676711977/expenseTracker_fhmewr.png">
