import { createContext } from "react";

// create theme context here
export const themeContext = createContext();
