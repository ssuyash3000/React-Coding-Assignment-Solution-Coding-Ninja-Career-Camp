// create language context here

import { createContext } from "react";

export const languageContext = createContext();
