### Create a React app that uses the Context API to share and update state between components.

Create and export the theme and language context and consume them inside of the Navbar and Home components such that the output matches the expected output gif.

Output:
<img src="https://res.cloudinary.com/dl26pbek4/image/upload/v1678269129/cn-gifs/dialect-app_ftq0sd.gif"/>
